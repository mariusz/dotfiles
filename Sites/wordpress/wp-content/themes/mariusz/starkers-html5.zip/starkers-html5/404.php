<?php
/**
 * @package WordPress
 * @subpackage Starkers HTML5
 */

get_header();
?>

	<h2>Error 404 - Not Found</h2>

<?php get_sidebar(); ?>

<?php get_footer(); ?>