<?php
/*
Template Name: Custom
*/
?>

<?php get_header(); ?>

<?php get_footer(); ?>